package parte_8_matrices;
import java.util.Random;

public class parte_8_ejercicio_1 {

    public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 10;
    public static int MAX = 10;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        cargar_matriz_aleatorio_int(matint);
        imprimir_matriz_int(matint);
        invertir_orden_matriz(matint);
        System.out.println("-------------");
        imprimir_matriz_int(matint);
    }

    public static void cargar_matriz_aleatorio_int(int[][] mat) {
        Random r = new Random();
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static void invertir_orden_matriz(int[][] matint) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            int indiceA = 0;
            int indiceB = MAX - 1;
            while (indiceA < indiceB) {
                invertir_orden_arreglo(indiceA, indiceB, matint[fila]);
                indiceA++;
                indiceB--;
            }
        }
    }

    public static void invertir_orden_arreglo(int indiceA, int indiceB, int[] arr) {
        int enteroTemporal = arr[indiceA];
        arr[indiceA] = arr[indiceB];
        arr[indiceB] = enteroTemporal;
    }
}