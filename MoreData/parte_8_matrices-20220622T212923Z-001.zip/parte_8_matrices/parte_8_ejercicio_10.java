package parte_8_matrices;
/*Hacer un programa que dada la matriz de secuencias de enteros definida y precargada, 
*permita obtener a trav�s de m�todos la posici�n de inicio y la posici�n de fin de 
*la secuencia ubicada a partir de una posici�n entera y una fila, ambas ingresadas 
*por el usuario. Finalmente, si existen imprima por pantalla ambas posiciones obtenidas.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class parte_8_ejercicio_10 {
	public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 20;
    public static int MAX = 20;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;
    public static final double probabilidad_numero = 0.4;
    public static final double probabilidad_letra = 0.4;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        char[][] matchar = new char[MAXFILA][MAXCOLUMNA];
        int columna, fila, inicio, fin, iniciochar, finchar;
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        try {
            //cargar_matriz_aleatorio_secuencias_int(matint);
            //imprimir_matriz_int(matint);
            cargar_matriz_aleatorio_secuencias_char(matchar);
            imprimir_matriz_char(matchar);
            System.out.println("Ingrese una columna: ");
            columna = Integer.valueOf(entrada.readLine());
            System.out.println("Ingrese una fila: ");
            fila = Integer.valueOf(entrada.readLine());
            //inicio = buscar_posicion_inicio(matint[fila], columna);
            //fin = buscar_posicion_fin(matint[fila], inicio);
            iniciochar = buscar_posicion_inicio_char(matchar[fila], columna);
            finchar = buscar_posicion_fin_char(matchar[fila], iniciochar);
            //System.out.println("El inicio de la secuencia es la pos [" + inicio + "]");
            //System.out.println("El final de la secuencia es la pos [" + fin + "]");
            System.out.println("El inicio de la secuencia es la pos [" + iniciochar + "]");
            System.out.println("El final de la secuencia es la pos [" + finchar + "]");
            
        } catch (Exception exc) {
            System.out.println(exc);
        }
    }

    public static void cargar_matriz_aleatorio_secuencias_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            cargar_arreglo_aleatorio_secuencias_int(mat[fila]);
        }
        System.out.println("");
    }

    public static void cargar_matriz_aleatorio_secuencias_char(char[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            cargar_arreglo_aleatorio_secuencias_char(mat[fila]);
        }
        System.out.println("");
    }

    public static void cargar_arreglo_aleatorio_secuencias_int(int[] arr) {
        Random r = new Random();
        arr[0] = 0;
        arr[MAX - 1] = 0;
        for (int pos = 1; pos < MAX - 1; pos++) {
            if (r.nextDouble() > probabilidad_numero) {
                arr[pos] = (r.nextInt(MAXVALOR - MINVALOR + 1) + MINVALOR);
            } else {
                arr[pos] = 0;
            }
        }
    }

    public static void cargar_arreglo_aleatorio_secuencias_char(char[] arr) {
        Random r = new Random();
        arr[0] = ' ';
        arr[MAX - 1] = ' ';
        for (int pos = 1; pos < MAX - 1; pos++) {
            if (r.nextDouble() > probabilidad_letra) {
                arr[pos] = (char) (r.nextInt(26) + 'a');
            } else {
                arr[pos] = ' ';
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static void imprimir_matriz_char(char[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            imprimir_arreglo_secuencias_char(mat[fila]);
            System.out.println("");
        }
    }

    public static void imprimir_arreglo_secuencias_char(char[] arr) {
        for (int pos = 0; pos < MAX; pos++) {
            System.out.print(arr[pos] + "|");
        }
    }

    public static int buscar_posicion_inicio(int[] arr, int pos) {
        while ((arr[pos] == 0) && (pos < MAX - 1)) {
            pos++;
        }
        return pos;
    }

    public static int buscar_posicion_fin(int[] arr, int pos) {
        while ((arr[pos] != 0) && (pos < MAX - 1)) {
            pos++;
        }
        return (pos - 1);
    }

    public static int buscar_posicion_inicio_char(char[] arr, int pos) {
        while ((arr[pos] == ' ') && (pos < MAX - 1)) {
            pos++;
        }
        return pos;
    }
    
    public static int buscar_posicion_fin_char(char[] arr, int pos){
        while ((arr[pos] != ' ') && (pos < MAX - 1)) {
            pos++;
        }
        return (pos - 1);
    }
}
