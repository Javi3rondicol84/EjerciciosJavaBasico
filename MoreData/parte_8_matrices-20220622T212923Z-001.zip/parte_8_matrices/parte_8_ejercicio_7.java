package parte_8_matrices;
/*Hacer un programa que dado una matriz ordenada creciente por filas de enteros 
de tama�o 4*5 que se encuentra precargada, solicite al usuario un numero entero 
y una fila, y luego inserte el numero en la matriz en la fila indicada manteniendo su orden.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;
public class parte_8_ejercicio_7 {
	public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 10;
    public static int MAX = 10;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        int entero, fila, pos = 0;
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        try {
            cargar_matriz_aleatorio_int(matint);
            ordenar_arreglo_seleccion(matint);
            imprimir_matriz_int(matint);
            System.out.println("Ingrese un entero: ");
            entero = Integer.valueOf(entrada.readLine());
            System.out.println("Ingrese una fila: ");
            fila = Integer.valueOf(entrada.readLine());
            pos = encontrar_pos_numero(matint[fila], entero);
            corrimiento_der(matint[fila], pos);
            imprimir_matriz_int(matint);
        } catch (Exception exc) {
            System.out.println(exc);
        }
    }

    public static void cargar_matriz_aleatorio_int(int[][] mat) {
        Random r = new Random();
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
            }
        }
    }

    public static void ordenar_arreglo_seleccion(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            int pos_menor, tmp;
            for (int i = 0; i < MAX; i++) {
                pos_menor = i;
                for (int j = i + 1; j < MAX; j++) {
                    if (mat[fila][j] < mat[fila][pos_menor]) {
                        pos_menor = j;
                    }
                }
                if (pos_menor != i) {
                    tmp = mat[fila][i];
                    mat[fila][i] = mat[fila][pos_menor];
                    mat[fila][pos_menor] = tmp;
                }
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static int encontrar_pos_numero(int[] mat, int entero) {
        int pos = 0;
        int ubicacion = -1;
        boolean encontrado = false;
        while ((pos <= MAX - 1) && (encontrado == false)) {
            if (mat[pos] >= entero) {
                ubicacion = pos;
                mat[pos] = entero;
                encontrado = true;
            } else {
                pos++;
            }
        }
        return ubicacion;
    }

    public static void corrimiento_der(int[] arrenteros, int pos) {
        int indice = MAX - 1;
        while (indice > pos) {
            arrenteros[indice] = arrenteros[indice - 1];
            indice--;
        }
    }

}
