package parte_8_matrices;
/*Hacer un programa que dado una matriz de enteros de tama�o 5*10 que se encuentra 
*precargada, solicite al usuario un numero entero y elimine todas las ocurrencia
*de numero en la matriz si existe. Mientras exista (en cada iteraci�n tiene que 
*buscar la posici�n fila y columna) tendr� que usar dicha posici�n para realizar
*un corrimiento a izquierda.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class parte_8_ejercicio_6 {

    public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 10;
    public static int MAX = 10;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;
    
    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        int entero;
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        try {
            cargar_matriz_aleatorio_int(matint);
            imprimir_matriz_int(matint);
            System.out.println("Ingrese un entero: ");
            entero = Integer.valueOf(entrada.readLine());
            buscar_ocurrencia_en_fila(matint, entero);
            imprimir_matriz_int(matint);
        } catch (Exception exc) {
            System.out.println(exc);
        }
    }

    public static void cargar_matriz_aleatorio_int(int[][] mat) {
        Random r = new Random();
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static void buscar_ocurrencia_en_fila(int[][] mat, int numero) {
        int fila = 0;
        int columna = MAXCOLUMNA;
        while ((fila < MAXFILA) && (columna == MAXCOLUMNA)) {
            buscar_ocurrencia_en_columna(mat[fila], numero);
            if (columna == MAXCOLUMNA) {
                fila++;
            }
        }
        
    }

    public static void buscar_ocurrencia_en_columna(int[] mat, int numero) {
        for (int posColumna = 0; posColumna < MAX; posColumna++) {
            if (mat[posColumna] == numero) {
                corrimiento_izq(mat, posColumna);
            }
        }
    }

    public static void corrimiento_izq(int[] matint, int posColumna) {
        for (int pos = posColumna; pos < MAX - 1; pos++) {
            matint[pos] = matint[pos + 1];
        }
    }
}
