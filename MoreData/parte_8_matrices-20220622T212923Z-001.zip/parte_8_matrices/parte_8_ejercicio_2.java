package parte_8_matrices;
import java.util.Random;
public class parte_8_ejercicio_2 {
	public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 10;
    public static int MAX = 10;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        int cantPares = 0;
        cargar_matriz_aleatorio_int(matint);
        imprimir_matriz_int(matint);
        cantPares = buscar_pares(matint, cantPares);
        System.out.println("La cantidad de numeros pares es: " + cantPares);
    }

    public static void cargar_matriz_aleatorio_int(int[][] mat) {
        Random r = new Random();
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static int buscar_pares(int[][] arr, int cantidad_pares) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                if ((arr[fila][columna]) % 2 == 0) {
                    cantidad_pares++;
                }
            }
        }
        return cantidad_pares;
    }
}
