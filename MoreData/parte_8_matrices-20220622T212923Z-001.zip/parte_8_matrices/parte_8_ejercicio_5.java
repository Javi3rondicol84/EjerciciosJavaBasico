package parte_8_matrices;
/*Hacer un programa que dado una matriz de enteros de tama�o 5*10 que se encuentra
*precargada, solicite al usuario un numero entero y elimine la primer ocurrencia 
*de numero en la matriz (un n�mero igual) si existe. Para ello tendr� que buscar 
*la posici�n y si est�, realizar un corrimiento a izquierda y no continuar buscando.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;


public class parte_8_ejercicio_5 {

	public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 10;
    public static int MAX = 10;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        int entero;
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        try {
            cargar_matriz_aleatorio_int(matint);
            imprimir_matriz_int(matint);
            System.out.println("Ingrese un entero: ");
            entero = Integer.valueOf(entrada.readLine());
            buscar_ocurrencia_en_fila(matint, entero);
            imprimir_matriz_int(matint);
        } catch (Exception exc) {
            System.out.println(exc);
        }
    }

    public static void cargar_matriz_aleatorio_int(int[][] mat) {
        Random r = new Random();
        for (int fila = 0; fila < MAXFILA; fila++) {
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static void buscar_ocurrencia_en_fila(int[][] mat, int numero) {
        int fila = 0;
        int columna = MAXCOLUMNA;
        while ((fila < MAXFILA) && (columna == MAXCOLUMNA)) {
            columna = buscar_ocurrencia_en_columna(mat[fila], numero);
            if (columna == MAXCOLUMNA) {
                fila++;
            }
        }
        corrimiento_izq(mat[fila], columna);
    }

    public static int buscar_ocurrencia_en_columna(int[] mat, int numero) {
        int posColumna = 0;
        while ((posColumna <= MAXCOLUMNA - 1) && (mat[posColumna] != numero)) {
            posColumna++;
        }
        return posColumna;
    }

    public static void corrimiento_izq(int[] matint, int posColumna) {
        for (int pos = posColumna; pos < MAX - 1; pos++) {
            matint[pos] = matint[pos + 1];
        }
    }
}
