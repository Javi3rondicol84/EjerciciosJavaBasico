package parte_8_matrices;
/*Hacer un programa que dada la matriz de secuencias de caracteres definida y precargada, 
*permita encontrar por cada fila la posici�n de inicio y fin de la ante�ltima secuencia 
*(considerar comenzar a buscarla a partir de la ultima posici�n de la fila).
 */

import java.util.Random;
public class parte_8_ejercicio_12 {

    public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 20;
    public static int MAX = 20;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;
    public static final double probabilidad_numero = 0.4;

    public static void main(String[] args) {
        int [][] matint =  new int [MAXFILA][MAXCOLUMNA];
        cargar_matriz_aleatorio_secuencias_int(matint);
        imprimir_matriz_secuencias_int(matint);
        encontrar_anteultima_secuencia(matint, 2);
    }
    
    public static void cargar_matriz_aleatorio_secuencias_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            cargar_arreglo_aleatorio_secuencias_int(mat[fila]);
        }
        System.out.println("");
    }

    public static void cargar_arreglo_aleatorio_secuencias_int(int[] arr) {
        Random r = new Random();
        arr[0] = 0;
        arr[MAX - 1] = 0;
        for (int pos = 1; pos < MAX - 1; pos++) {
            if (r.nextDouble() > probabilidad_numero) {
                arr[pos] = (r.nextInt(MAXVALOR - MINVALOR + 1) + MINVALOR);
            } else {
                arr[pos] = 0;
            }
        }
    }

    public static void imprimir_matriz_secuencias_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }
    
    public static void encontrar_anteultima_secuencia(int[][] mat, int pos){
        for (int fila = 0; fila < MAXFILA; fila++) {
            encontrar_anteultima_secuencia_fila(mat[fila], pos);
        }
    }
    
    public static void encontrar_anteultima_secuencia_fila(int[] arr, int pos) {
        int fin = MAX;
        int inicio = MAX - 1;
        int i = 0;
        while ((0 <= inicio)&&(i<pos)) {
            inicio = buscar_posicion_inicio(arr, fin - 1);
            if (inicio >= 0) {
                fin = buscar_posicion_fin(arr, inicio);
                i++;
            }
        }
        System.out.println("Inicio anteultima secuencia: [" + inicio + "]");
        System.out.println("Fin anteultima secuencia: [" + fin + "]");
    }
    
    public static int buscar_posicion_inicio(int[] arr, int pos) {
        while ((pos >= 0) && (arr[pos] == 0)) {
            pos--;
        }
        return pos;
    }

    public static int buscar_posicion_fin(int[] arr, int pos) {
        while ((pos >= 0) && (arr[pos] != 0)) {
            pos--;
        }
        return pos + 1;
    }
    
}
