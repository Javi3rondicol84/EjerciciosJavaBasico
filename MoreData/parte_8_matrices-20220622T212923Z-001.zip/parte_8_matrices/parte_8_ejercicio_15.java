package parte_8_matrices;
/*Hacer un programa que dada la matriz de secuencias de caracteres definida y 
*precargada elimine todas las secuencias que tienen orden descendente entre sus elementos.
 */
public class parte_8_ejercicio_15 {
	public static final int MAXFILA = 3;
    public static final int MAXCOLUMNA = 20;
    public static int MAX = 20;

    public static void main(String[] args) {
        int[][] matint = {{0, 1, 2, 0, 3, 4, 0, 6, 5, 4, 3, 0, 0, 2, 3, 5, 0, 8, 5, 0},
                          {0, 1, 5, 0, 3, 4, 0, 6, 8, 4, 3, 0, 0, 2, 3, 5, 0, 8, 5, 0},
                          {0, 1, 2, 3, 3, 4, 0, 6, 5, 7, 3, 0, 0, 5, 2, 1, 0, 8, 9, 0}};
        imprimir_matriz_secuencias_int(matint);
        eliminar_secuencias_descendentes(matint);
        imprimir_matriz_secuencias_int(matint);
    }

    public static void imprimir_matriz_secuencias_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }
    

    public static void eliminar_secuencias_descendentes(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            eliminar_secuencias_descendentes_fila(mat[fila]);
        }
    }

    public static void eliminar_secuencias_descendentes_fila(int[] arr) {
        int inicio, fin;
        inicio = 0;
        fin = -1;
        while (inicio < MAX - 1) {
            inicio = obtener_inicio_secuencia(arr, fin + 1);
            if (inicio < MAX - 1) {
                fin = obtener_fin_secuencia(arr, inicio);
                if (es_descendente(arr, inicio, fin) == true) {
                    corrimiento_izq(arr, inicio, fin);
                }
            }
        }
    }

    public static boolean es_descendente(int[] arr, int inicio, int fin) {
        int i = inicio;
        while ((i < fin) && (arr[i + 1] < arr[i])) {
            i++;
        }
        return (i==fin);
    }

    public static int obtener_inicio_secuencia(int[] arr, int pos) {
        while ((pos < MAX - 1) && (arr[pos] == 0)) {
            pos++;
        }
        return pos;
    }

    public static int obtener_fin_secuencia(int[] arr, int pos) {
        while ((pos < MAX - 1) && (arr[pos] != 0)) {
            pos++;
        }
        return pos - 1;
    }

    public static void corrimiento_izq(int[] arr, int inicio, int fin) {
        int longuitud = (fin + 1) - inicio;
        while (longuitud > 0) {
            for (int i = inicio; i < MAX - 1; i++) {
                arr[i] = arr[i + 1];
            }
            longuitud--;
        }
    }
}
