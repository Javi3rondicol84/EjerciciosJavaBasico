package parte_8_matrices;
/*Hacer un programa que dado una matriz de enteros de tama�o 4*5 que se encuentra 
*precargada, solicite al usuario el ingreso de una fila y dos n�meros enteros 
*(columnas de la matriz), y ordene de forma creciente la matriz en la fila 
*indicada entre las dos posiciones columnas ingresadas.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class parte_8_ejercicio_9 {
	 public static final int MAXFILA = 5;
	    public static final int MAXCOLUMNA = 10;
	    public static int MAX = 10;
	    public static final int MAXVALOR = 10;
	    public static final int MINVALOR = 1;

	    public static void main(String[] args) {
	        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
	        int columna_1, fila, columna_2;
	        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
	        try {
	            cargar_matriz_aleatorio_int(matint);
	            imprimir_matriz_int(matint);
	            System.out.println("Ingrese una fila: ");
	            fila = Integer.valueOf(entrada.readLine());
	            System.out.println("Ingrese una columna: ");
	            columna_1 = Integer.valueOf(entrada.readLine());
	            System.out.println("Ingrese otra columna: ");
	            columna_2 = Integer.valueOf(entrada.readLine());
	            ordenar_arreglo(matint[fila], columna_1, columna_2);
	            imprimir_matriz_int(matint);
	        } catch (Exception exc) {
	            System.out.println(exc);
	        }
	    }

	    public static void cargar_matriz_aleatorio_int(int[][] mat) {
	        Random r = new Random();
	        for (int fila = 0; fila < MAXFILA; fila++) {
	            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
	                mat[fila][columna] = (r.nextInt(MAXVALOR + MINVALOR - 1) + MINVALOR);
	            }
	        }
	    }

	    public static void imprimir_matriz_int(int[][] mat) {
	        for (int fila = 0; fila < MAXFILA; fila++) {
	            System.out.print("|");
	            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
	                System.out.print(mat[fila][columna] + "|");
	            }
	            System.out.println("");
	        }
	    }

	    public static void ordenar_arreglo(int[] arr, int pos1, int pos2) {
	        int pos_menor, tmp;
	        for (int i = pos1; i < pos2; i++) {
	            pos_menor = i;
	            for (int j = i + 1; j < pos2; j++) {
	                if (arr[j] < arr[pos_menor]) {
	                    pos_menor = j;
	                }
	            }
	            if (pos_menor != i) {
	                tmp = arr[i];
	                arr[i] = arr[pos_menor];
	                arr[pos_menor] = tmp;
	            }
	        }
	    }

}
