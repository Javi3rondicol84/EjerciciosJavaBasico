package parte_8_matrices;
/*Hacer un programa que dada la matriz de secuencias de enteros definida y precargada
*permita encontrar por cada fila la posici�n de inicio y fin de la secuencia �
*cuya suma de valores sea mayor.
 */

import java.util.Random;

public class parte_8_ejercicio_11 {
	public static final int MAXFILA = 5;
    public static final int MAXCOLUMNA = 20;
    public static int MAX = 20;
    public static final int MAXVALOR = 10;
    public static final int MINVALOR = 1;
    public static final double probabilidad_numero = 0.4;

    public static void main(String[] args) {
        int[][] matint = new int[MAXFILA][MAXCOLUMNA];
        cargar_matriz_aleatorio_secuencias_int(matint);
        imprimir_matriz_int(matint);
        imprimir_suma_mayor_secuencias_matriz(matint);
    }

    public static void cargar_matriz_aleatorio_secuencias_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            cargar_arreglo_aleatorio_secuencias_int(mat[fila]);
        }
        System.out.println("");
    }

    public static void cargar_arreglo_aleatorio_secuencias_int(int[] arr) {
        Random r = new Random();
        arr[0] = 0;
        arr[MAX - 1] = 0;
        for (int pos = 1; pos < MAX - 1; pos++) {
            if (r.nextDouble() > probabilidad_numero) {
                arr[pos] = (r.nextInt(MAXVALOR - MINVALOR + 1) + MINVALOR);
            } else {
                arr[pos] = 0;
            }
        }
    }

    public static void imprimir_matriz_int(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.print("|");
            for (int columna = 0; columna < MAXCOLUMNA; columna++) {
                System.out.print(mat[fila][columna] + "|");
            }
            System.out.println("");
        }
    }

    public static void imprimir_suma_mayor_secuencias_matriz(int[][] mat) {
        for (int fila = 0; fila < MAXFILA; fila++) {
            System.out.println("Para la fila " + fila);
            imprimir_suma_mayor_secuencia(mat[fila]);
        }
    }
    
    public static void imprimir_suma_mayor_secuencia(int[] arr) {
        int inicio, fin, suma;
        inicio = 0;
        fin = -1;
        int mayorSuma = 0;
        int inicioMayor = 0;
        int finMayor = 0;
        while ((inicio < MAX - 1)) {
            inicio = buscar_posicion_inicio(arr, fin + 1);
            if (inicio < MAX - 1) {
                fin = buscar_posicion_fin(arr, inicio);
                suma = obtener_suma(arr, inicio, fin);
                if (suma > mayorSuma) {
                    mayorSuma = suma;
                    inicioMayor = inicio;
                    finMayor = fin;
                }
            }
        }
        System.out.println("La mayor suma de la secuencia de " + inicioMayor + " a " + finMayor + " es " + mayorSuma);
    }
    
    public static int buscar_posicion_inicio(int[] arr, int pos) {
        while ((arr[pos] == 0) && (pos < MAX - 1)) {
            pos++;
        }
        return pos;
    }

    public static int buscar_posicion_fin(int[] arr, int pos) {
        while ((arr[pos] != 0) && (pos < MAX - 1)) {
            pos++;
        }
        return (pos - 1);
    }
    
    public static int obtener_suma(int[] arr, int inicio, int fin) {
        int suma = 0;
        for (int i = inicio; i <= fin; i++) {
            suma += arr[i];
        }
        return suma;
    }
}
